﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Expense_Tracker.Models
{
    public class Category
    {
        public int CategoryId { get; set; }
        [Required, StringLength(50), Display(Name = "Category Name")]
        public string CategoryName { get; set; }
        //Nev
        public virtual ICollection<Expenses> Expenses { get; set; }
    }
    public class Expenses
    {
        public int ExpensesId { get; set; }
        [Required, Display(Name = "Expenses Date"), Column(TypeName = "date"), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [ExpenseDateValidation(ErrorMessage = "Expense Date do not future date")]
        public DateTime ExpensesDate { get; set; }
        [Required, Display(Name = "Expenses Amount")]
        public decimal ExpensesAmount { get; set; }
        //FK
        [ForeignKey("Category")]
        public int CategoryId { get; set; }
        //Nev
        public virtual Category Category { get; set; }
    }
    public class ExpensesDbContext : DbContext
    {
        public ExpensesDbContext(DbContextOptions<ExpensesDbContext> options) : base(options)
        {

        }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Expenses> Expenses { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.Entity<Category>(entity => {
                entity.HasIndex(e => e.CategoryName).IsUnique();
            });
        }
    }
}
